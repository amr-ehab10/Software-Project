<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Online Study</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    
    <?php 
session_start();
include 'database.php';
?>

</head>
<body>

<div class="divTableRow">
    <div class="divTableHead">ID</div>
    <div class="divTableHead">CourseName</div>
    <div class="divTableHead">CourseID</div>
    <div class="divTableHead">CourseType</div>
    <div class="divTableHead">CourseCost</div>
    <div class="divTableHead">CourseWeeks</div>
    <div class="divTableHead">CourseHours</div>
    <div class="divTableHead">Start_Date</div>
    <div class="divTableHead">End_Date</div>
    <div class="divTableHead">Edit</div>
    <div class="divTableHead">Delete</div>
</div>
</div>
<div class="divTableBody">

<?php
      echo $view->output();
    // output data of each row
   // while ($row = $result->fetch_assoc()) {
    //}

    

?>



<div class="divTableRow">
    <div class="divTableCell"> </div>  
    <div class="divTableCell"> 
        <input type="text"  id="fruit_name" placeholder="Enter Fruit name" name="fruit_name"> 
    </div>
    <div class="divTableCell"> 
       <input type="Number" step="0.01" min="0"  id="price" placeholder="Enter Price" name="price">
    </div>
    <div class="divTableCell"> <button type="submit" class="btn btn-default">Submit</button> </div>

</div>
</div>
</div>
</form>
</body>
</html>
