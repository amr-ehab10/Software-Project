<?php
  define('__ROOT__', "../app/");
  require_once(__ROOT__ . "model/CourseModel.php");
  require_once(__ROOT__ . "controller/CourseController.php");
 // require_once(__ROOT__ . "view/bar.php");

  $model = new Course();
  $controller = new CourseController($model);
//  $view = new Bar($controller, $model);


?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="HTTPS://fonts.googleapis.com/css?family=Poiret+One&amp;subset=cyrillic,latin-ext" rel="stylesheet">
<link href="HTTPS://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css">
<link rel="stylesheet" type="text/css" href="../lib/css/style.css">
</head>
<body id="bod">

    <center><h1 style="color: #00043c;margin-top:50px;margin-top: 50px;"><span>Add Courses</span></h1></center>

  
<div class="s">
 <div class="ss">
    <div class="inss">
    <form action="index.php?action=AddCourse" method="post">
    <label>CourseName </label><br>
    
    <input type="text" maxlength="16" name="name" id="name"  >
    <span id="availability"></span>
            <br><br>
    <label>CourseID</label><br>
    <input type="text" maxlength="16" name="courseid" id="courseid" required>
            <br><br>
    
    <label>CourseWeeks</label><br>
    <input type="text" maxlength="11" name="weeks" id="weeks"  >
            <br><br>        

    <label>CourseHours</label><br>
            
    <input type="text" name="hours" id="hours" >
            <br><br>
    <label>CourseType</label><br>
    <input type="text" maxlength="30" name="type" id="types">
            <br><br>
    <label>CourseCost</label><br>
    <input type="text" maxlength="30" name="cost" id="cost" >
            <br><br>        

    <label>StartDate</label><br>
    <input type="date" name="start" id="start" >
          
<br>
    <label>EndDate</label><br>
    <input type="date" name="end" id="end" >
         
            <br>
        
        <br>
        <input type="submit"   name="submit"   value="Save"><br>
        </div>
    </div>
    </form>
