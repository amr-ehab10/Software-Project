<?php

  require_once(__ROOT__ . "controller/Controller.php");

class UserController extends Controller{
    public function loginController() {
          // Escape user inputs for security
    $email = $_REQUEST['email'];
    $password = $_REQUEST['password'];

      $this->model->login($email,$password);
    }

    public function signupController(){
     $fname = $_REQUEST['firstname'];
		 $lname = $_REQUEST['lastname'];
		 $email = $_REQUEST['email'];
		 $password = $_REQUEST['password'];
		 $phone = $_REQUEST['phone'];
		 $age = $_REQUEST['age'];
    // $image=$_FILES['img']['name'];
     
     $this->model->signup($fname,$lname,$email,$password,$phone,$age);

    }
    public function profileController(){

      $email = $_REQUEST['email'];

      $this->model->viewprofile($email);
    }

  }