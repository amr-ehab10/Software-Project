<?php

  require_once(__ROOT__ . "controller/Controller.php");

class CourseController extends Controller{
    public function AddCourse() {
          // Escape user inputs for security
          $coursename=$_REQUEST['name'];
          $courseid=$_REQUEST['courseid'];
          $courseweeks=$_REQUEST['weeks'];
          $coursehours=$_REQUEST['hours'];
          $coursetype=$_REQUEST['type'];
          $coursecost=$_REQUEST['cost'];
          $startdate=$_REQUEST['start'];
          $enddate=$_REQUEST['end'];
  
      $this->model->addcourses($coursename,$courseid,$courseweeks,$coursehours,$coursetype,$coursecost,$startdate,$enddate);
    }

    public function EditCourse(){

        $coursename=$_REQUEST['name'];
        $courseid=$_REQUEST['courseid'];
        $courseweeks=$_REQUEST['weeks'];
        $coursehours=$_REQUEST['hours'];
        $coursetype=$_REQUEST['type'];
        $coursecost=$_REQUEST['cost'];
        $startdate=$_REQUEST['start'];
        $enddate=$_REQUEST['end'];

     $this->model->editcourse($coursename,$courseID,$courseweeks,$coursehours,$coursetype,$coursecost,$startdate,$enddate);

    }
    public function DeleteCourse(){
        $id = $_REQUEST['id'];
        $this->model->deletecourse($id);
      }
    }