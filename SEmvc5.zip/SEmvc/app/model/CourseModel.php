<?php
//session_start();
require_once(__ROOT__ . "model/Model.php");

class Course extends Model{ 
        private $coursename;
        private $courseid;
        private $coursedescription;
        private $coursetype;
        private $coursecost;
        private $courseweeks;
        private $coursehours;
        private $startdate;
        private $enddate;
        private $dbh;

    function __construct($coursename="",$courseid="",$coursetype="",$startdate="",$enddate="") {
            $this->coursename = $coursename;
            $this->courseid = $courseid;
            $this->coursetype= $coursetype;
            $this->startdate = $startdate;
            $this->enddate = $enddate;
          }
          function getCourseName() {
            return $this->coursename;
          }
          function setCourseName($coursename) {
            return $this->coursename = $coursename;
          }
          
          function getCourseID() {
            return $this->password;
          }
          function setCourseID($courseid) {
            return $this->courseid = $courseid;
          }
          function getCourseType($coursetype) {
            return $this->coursetype;
          }
          function setCourseType($coursetype) {
            return $this->coursetype = $coursetype;
          }
          function getID() {
            return $this->id;
          }
      
static function addcourses($coursename,$courseID,$courseweeks,$coursehours,$coursetype,$coursecost,$startdate,$enddate){

        $coursename=$_POST['name'];
        $courseid=$_POST['courseid'];
        $courseweeks=$_POST['weeks'];
        $coursehours=$_POST['hours'];
        $coursetype=$_POST['type'];
        $coursecost=$_POST['cost'];
        $startdate=$_POST['start'];
        $enddate=$_POST['end'];


  $sql = "INSERT into  Course(CourseName,CourseID) Values('$coursename','$courseid');";
  $sql1 = "SELECT CourseID FROM Course WHERE CourseName='$coursename' AND CourseID='$courseid'";
  //$sql .= "INSERT INTO  Course_Time_Info(CourseWeeks,CourseHours,StartDate,End_Date,CourseID) Values('$courseweeks','$coursehours','$startdate','$enddate','$courseid');";
  $dbh = new Dbh();

 if($dbh->query($sql) == true){

  $courseID = $dbh->query($sql1);
  $row = $dbh->fetchRow($courseID);
  $id = $row['CourseID'];

  $sql2 = "INSERT INTO  Course_Info(CourseType,CourseCost,CourseID) Values ('$coursetype','$coursecost','$id')";
  $sql3 = "INSERT INTO  Course_Time_Info(CourseWeeks,CourseHours,StartDate,End_Date,CourseID) Values('$courseweeks','$coursehours','$startdate','$enddate','$id');";
  if($dbh->query($sql2) === true){
    if($dbh->query($sql3) === true){
    echo" Added Courses successfully";
    //header("Location:index.php");
   // $this->fillArray();
} else{
    echo "ERROR: Could not able to execute $sql. " . $conn->error;
}
        
    }
  }
}
    function deletecourse($id){
  
        $sql="DELETE from Fruits where id='$id';";
        if($this->dbh->query($sql) === true){
                echo "Course Deleted successfully.";
                header("Location:index.php");
               // $this->fillArray();
            } else{
                echo "ERROR: Could not able to execute $sql. " . $conn->error;
            }
      }
        }

    

      
?>