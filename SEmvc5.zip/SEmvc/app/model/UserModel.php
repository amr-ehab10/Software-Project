<?php
 
  session_start();
  require_once(__ROOT__ . "model/Model.php");
class User extends Model{
  private $id;
  private $fname;
  private $lname;
  private $telephone;
  private $email;
  private $password; 
  private $image; 
  private $dbh;
  private $users;

  function __construct($email="",$password="",$fname="",$lname="") {
    $this->email = $email;
    $this->password = $password;
    $this->fname = $fname;
    $this->lname = $lname; 
  }
  function setName(){
    return $this->fname = $fname;
    return $this->lname = $lname;
  }
  function getName(){
    return $this->fname;
    return $this->lname;
  }
  function getEmail() {
    return $this->email;
  }
  function setEmail($email) {
    return $this->email = $email;
  }
  
  function getPassword() {
    return $this->password;
  }
  function setPassword($password) {
    return $this->password = $password;
  }
  function setTelephone(){
    return $this->telephone = $telephone;
  }
  function getTelephone(){
    return $this->telephone;
  }
  function getID(){
    return $this->id;
  }
  function getImage(){
    return $this->image;
  }
 
    function getusers(){
      return $this->users;
    }
  

static function login($email,$password){
  
	$email=$_POST['email'];
	$password=$_POST['password'];

$sql = "SELECT email, password , ID FROM User where email='$email' AND password='$password'";
echo $sql;
$dbh = new Dbh();
$result = $dbh->query($sql);
$row=$dbh->fetchRow();


if (!empty($row)){
  
  $userID = "SELECT UserType FROM User_Type_Info where User_Id='".$row['ID']."'";
  $result = $dbh->query($userID);
  $row1=$dbh->fetchRow($result);

  if (!empty($row1)){
  
if($row1['UserType']=='Student'){
    $_SESSION['type']='Student';
  }
if($row1['UserType']=='Teacher'){
    $_SESSION['type']='Teacher';
  }
if($row1['UserType']=='Admin'){
    $_SESSION['type']='Admin';
  }

echo" login successfully";

}

else{
echo "Invalid Email or Password or still not accepted";
}	

}
}

function signup($fname,$lname,$email,$password,$phone,$age){
     
		 $fname = $_POST['firstname'];
		 $lname = $_POST['lastname'];
		 $email = $_POST['email'];
		 $password = $_POST['password'];
		 $phone = $_POST['phone'];
		 $age = $_POST['age'];
     //$image=$_FILES['img']['name'];
     
  $sql = "INSERT into  User(FirstName,LastName,Email,Password) Values('$fname','$lname','$email','$password');";
  $sql1 = "SELECT ID FROM User WHERE FirstName='$fname' AND LastName='$lname' AND Email='$email'";
  $dbh = new Dbh();
  
  if($dbh->query($sql) == true){
    
    $userID = $dbh->query($sql1);
    $row = $dbh->fetchRow($userID);
     
    $id = $row['ID'];
     $sql2 = "INSERT into  User_Info (Age,Telephone,User_Id) Values('$age','$phone','$id');";
  
   $sql3 = "INSERT INTO  User_Type_Info(User_Id,UserType) Values(($id),'Student');";
    if($dbh->query($sql2) == true){
      if($dbh->query($sql3) == true){
      
    echo" Signup successfully";
   
      }
    }
  }
 else{
    echo "ERROR: Could not able to execute $sql. " . $conn->error;
}
        
    }

    function viewprofile($email){

      $email = $_POST['email'];
      $sql="SELECT * from User where email = '$email' ";
      $dbh = new dbh();
      $result = $dbh->query($sql);
      if(!empty($result)){
        $row=$dbh->fetchRow($result);
        }else{
          echo "ERROR: Could not able to execute $sql. " . $conn->error;
        }
    }
}  

