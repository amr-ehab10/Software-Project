<?php
require_once(__ROOT__ . "view/View.php");
class ViewTable extends View{
	
    public function output(){
        $str = "";
        //echo $this->model->getFruits();
        
        foreach($this->model->getFruits() as $fruit){
            $str= $str . '<div class="container">'.
            '<div class="divTableCell"> ' . $fruit->getID() . " </div> ".
            '<div class="divTableCell"> ' . $fruit->getName() . " </div> ".
            '<div class="divTableCell"> ' . $fruit->getPrice() . " </div> ".
            '<div class="divTableCell"><a href="edit.php?id='.$fruit->getID().'">Edit Fruit </a></div> '.
            '<div class="divTableCell"><a href="delete.php?id='.$fruit->getID().'">Delete Fruit </a></div> '.
            '</div>';
        }
    
       
        return $str;
    }