-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 04, 2020 at 03:05 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Online Course`
--

-- --------------------------------------------------------

--
-- Table structure for table `Course`
--

CREATE TABLE `Course` (
  `ID` int(11) NOT NULL,
  `CourseName` varchar(255) NOT NULL,
  `CourseID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Course`
--

INSERT INTO `Course` (`ID`, `CourseName`, `CourseID`) VALUES
(11, 'ay haga', ''),
(16, 'Artificial Int', 'AI302'),
(3, 'Arabic', 'ar202'),
(8, 'Arabic', 'ar204'),
(10, 'chemistry', 'c201'),
(2, 'Networks', 'csc101'),
(14, 'DataBase', 'DB12'),
(1, 'English AL', 'eng101'),
(5, 'English OL', 'eng102'),
(4, 'Math', 'm402'),
(12, 'Math', 'math201'),
(9, 'Physics', 'ph201');

-- --------------------------------------------------------

--
-- Table structure for table `Course_Info`
--

CREATE TABLE `Course_Info` (
  `CourseType` varchar(255) NOT NULL,
  `CourseCost` int(11) NOT NULL,
  `CourseID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Course_Info`
--

INSERT INTO `Course_Info` (`CourseType`, `CourseCost`, `CourseID`) VALUES
('IG', 200, 'eng101'),
('CS', 350, 'csc101'),
('National', 250, 'ar202'),
('National', 200, 'm402'),
('National', 252, 'eng102'),
('National', 250, 'ar204'),
('IG', 600, 'ph201'),
('National', 600, 'c201'),
('Statistics', 200, ''),
('Data Analysis', 150, ''),
('CS', 200, 'AI302');

-- --------------------------------------------------------

--
-- Table structure for table `Course_Time_Info`
--

CREATE TABLE `Course_Time_Info` (
  `CourseWeeks` int(11) NOT NULL,
  `CourseHours` int(11) NOT NULL,
  `StartDate` date NOT NULL,
  `End_Date` date NOT NULL,
  `CourseID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Course_Time_Info`
--

INSERT INTO `Course_Time_Info` (`CourseWeeks`, `CourseHours`, `StartDate`, `End_Date`, `CourseID`) VALUES
(25, 600, '2020-04-02', '2020-05-09', 'ph201'),
(45, 20, '2020-04-30', '2020-05-09', 'c201'),
(850, 250, '2020-05-03', '2020-06-06', ''),
(40, 90, '2020-05-03', '2020-06-06', ''),
(40, 120, '2020-05-03', '2020-06-06', 'AI302');

-- --------------------------------------------------------

--
-- Table structure for table `Reserved_Students`
--

CREATE TABLE `Reserved_Students` (
  `ID` int(11) NOT NULL,
  `CourseID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Reserved_Teachers`
--

CREATE TABLE `Reserved_Teachers` (
  `ID` int(11) NOT NULL,
  `SectionName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Section`
--

CREATE TABLE `Section` (
  `SectionName` varchar(255) NOT NULL,
  `SectionCost` int(11) NOT NULL,
  `SectionTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `ID` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`ID`, `FirstName`, `LastName`, `Email`, `Password`) VALUES
(12, 'Admin', 'Admin', 'admin@hotmail.com', '123456'),
(13, 'Kamal', 'Osama', 'kamal@hotmail.com', '123456789'),
(14, 'User ', 'Student', 'Student@gmail.com', '123456'),
(15, 'Teacher', 'User', 'Teacher@gmail.com', '123456'),
(16, 'Teacher', 'Teacher', 'teacher@gmail.com', '123456'),
(17, 'Moataz', 'Lasheen', 'Moataz@gmail.com', '123456'),
(18, 'ahmed', 'ahyman', 'ahmed@gmail.com', '1234567'),
(19, 'Mohamed', 'Adel', 'Student@gmail.com', '$2y$10$fBUJ/b8heIUzEw3IiAr9IuvQ3RqI136/7TwsefpcDz.ei4uQ5Mjfe'),
(20, 'Teacher', 'Tamer', 'teacher@gmail.com', '$2y$10$c4j2hqmZFhLrmHZgDQixV.UJZ3x.2Eq2LGZqsojjSP5rwzYndowQ2'),
(21, 'amer', 'medhat', 'Medhat@yahoo.com', '123456'),
(22, 'Amr', 'Ehab', 'amrehab@yahoo.com', '123456'),
(23, 'Omar', 'Nader', 'Nader@gmail.com', '123456'),
(24, 'Seif', 'Mohamed', 'Seif@yahoo.com', '123456'),
(25, 'Mahmoud', 'Mario', 'Mario@yahoo.com', '123456'),
(27, 'Micheal', 'Asharaf', 'Mic@yahoo.com', '123456'),
(33, 'Mohamed', 'Osama', 'mika@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `User_Info`
--

CREATE TABLE `User_Info` (
  `Age` int(11) NOT NULL,
  `Telephone` int(11) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `User_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User_Info`
--

INSERT INTO `User_Info` (`Age`, `Telephone`, `Image`, `User_Id`) VALUES
(25, 1154389687, 'face.jpeg', 11),
(30, 1154389678, 'face.jpeg', 12),
(25, 1023903532, 'dettol.jpg', 13),
(20, 1154389687, 'face.jpeg', 14),
(25, 1003153578, '20190828114605465.jpg', 15),
(23, 1003153562, 'Sanitizer.jpg', 16),
(26, 1023903532, 'Sanitizer.jpg', 17),
(22, 1023903532, 'dettol.jpg', 18),
(20, 1154389690, 'face.jpeg', 19),
(60, 1154389673, 'Sanitizer.jpg', 20),
(20, 1003153562, NULL, 33),
(20, 1003153562, NULL, 33);

-- --------------------------------------------------------

--
-- Table structure for table `User_Type_Info`
--

CREATE TABLE `User_Type_Info` (
  `UserType` varchar(255) NOT NULL,
  `User_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User_Type_Info`
--

INSERT INTO `User_Type_Info` (`UserType`, `User_Id`) VALUES
('Admin', 12),
('Admin', 13),
('Student', 14),
('Student', 15),
('Teacher', 16),
('Teacher', 17),
('Student', 33);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Course`
--
ALTER TABLE `Course`
  ADD PRIMARY KEY (`CourseID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `Course_Info`
--
ALTER TABLE `Course_Info`
  ADD KEY `CourseID` (`CourseID`);

--
-- Indexes for table `Course_Time_Info`
--
ALTER TABLE `Course_Time_Info`
  ADD KEY `CourseID` (`CourseID`);

--
-- Indexes for table `Reserved_Students`
--
ALTER TABLE `Reserved_Students`
  ADD KEY `CourseID` (`CourseID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `Reserved_Teachers`
--
ALTER TABLE `Reserved_Teachers`
  ADD KEY `ID` (`ID`),
  ADD KEY `SessionName` (`SectionName`);

--
-- Indexes for table `Section`
--
ALTER TABLE `Section`
  ADD PRIMARY KEY (`SectionName`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `User_Info`
--
ALTER TABLE `User_Info`
  ADD KEY `User_Id` (`User_Id`);

--
-- Indexes for table `User_Type_Info`
--
ALTER TABLE `User_Type_Info`
  ADD KEY `User_Id` (`User_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Course`
--
ALTER TABLE `Course`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Course_Info`
--
ALTER TABLE `Course_Info`
  ADD CONSTRAINT `Course_Info_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `Course` (`CourseID`);

--
-- Constraints for table `Course_Time_Info`
--
ALTER TABLE `Course_Time_Info`
  ADD CONSTRAINT `Course_Time_Info_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `Course` (`CourseID`);

--
-- Constraints for table `Reserved_Students`
--
ALTER TABLE `Reserved_Students`
  ADD CONSTRAINT `Reserved_Students_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `Course` (`CourseID`),
  ADD CONSTRAINT `Reserved_Students_ibfk_2` FOREIGN KEY (`ID`) REFERENCES `User` (`ID`);

--
-- Constraints for table `Reserved_Teachers`
--
ALTER TABLE `Reserved_Teachers`
  ADD CONSTRAINT `Reserved_Teachers_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `User` (`ID`),
  ADD CONSTRAINT `Reserved_Teachers_ibfk_2` FOREIGN KEY (`SectionName`) REFERENCES `Section` (`SectionName`);

--
-- Constraints for table `User_Info`
--
ALTER TABLE `User_Info`
  ADD CONSTRAINT `User_Info_ibfk_1` FOREIGN KEY (`User_Id`) REFERENCES `User` (`ID`);

--
-- Constraints for table `User_Type_Info`
--
ALTER TABLE `User_Type_Info`
  ADD CONSTRAINT `User_Type_Info_ibfk_1` FOREIGN KEY (`User_Id`) REFERENCES `User` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
